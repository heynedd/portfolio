# Iden — Motion Portfolio

Versi percobaan animasi editorial, dengan identitas Iden sendiri. Referensi pendekatan: https://haoqi.design/ . Tidak menyalin kode, aset, atau teks dari website referensi. Animasi adalah interpretasi, bukan reproduksi 1:1.

## Membuka di komputer

Ekstrak ZIP, lalu buka index.html dengan Chrome, Edge, atau Firefox. Semua animasi berjalan dengan JavaScript bawaan browser; tidak perlu npm, build, API key, atau backend. Google Fonts memerlukan internet; jika gagal, font fallback tetap tampil.

## Deploy ke GitHub Pages

1. Cadangkan repository portfolio lama sebelum mengganti file.
2. Buat atau buka repository GitHub. Untuk GitHub Free, gunakan repository public.
3. Upload isi folder ZIP, bukan file ZIP-nya. Pastikan index.html berada langsung di root repository bersama folder assets.
4. Buka Settings → Pages → Build and deployment.
5. Pada Source pilih Deploy from a branch, branch main, folder /(root), lalu Save.
6. Tunggu proses penerbitan selesai, lalu buka tautan yang ditampilkan GitHub Pages. Perubahan dapat memerlukan beberapa menit.

Repository username.github.io menghasilkan alamat utama; repository bernama lain menghasilkan alamat dengan /nama-repository/. Asset menggunakan path relatif sehingga keduanya didukung. Tidak ada routing SPA atau backend.

Dokumentasi resmi: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Isi paket

- index.html: seluruh konten, tautan project, pengalaman, dan kontak.
- assets/css/motion.css: tema baru, layout desktop/mobile, dan CSS animation.
- assets/js/main.js: terjemahan dasar dan kontrol detail project.
- assets/js/v3.js: perluasan terjemahan organisasi dari portfolio sebelumnya.
- assets/js/motion.js: copy baru EN/ID, native scroll reveal, parallax, tilt, cursor label, dan pengaturan motion.
- assets/img: foto dan mockup dari portfolio asli.

## Cara mengubah

Teks dasar ada di index.html dan kamus main.js. Teks yang diperbarui pada versi ini ada di kamus en/id pada motion.js. Ubah kedua bahasa agar tetap konsisten. Tautan project/email/WhatsApp ada di index.html. Warna utama dan ukuran teks ada di motion.css.

## Animasi dan aksesibilitas

- Headline muncul berurutan tanpa menahan pengguna di loading screen.
- Gambar project memiliki parallax scroll ringan dan tilt mengikuti pointer desktop.
- Label PROJECT mengikuti pointer saat berada di gambar; label ini dekoratif, bukan tombol.
- Konten di bawah layar muncul ketika masuk viewport.
- Bagian kemampuan menyorot fokus saat scroll.
- Ticker dapat dihentikan melalui Pause motion/Jeda animasi. Preferensi disimpan hanya pada perangkat pengguna.
- prefers-reduced-motion menonaktifkan gerak. Perangkat sentuh menggunakan tampilan tanpa hover/tilt.
- Tanpa JavaScript, konten utama, gambar, navigasi, dan tautan eksternal tetap terbaca. Pengalih bahasa dan detail interaktif membutuhkan JavaScript.

## Sebelum digunakan untuk melamar

Verifikasi kembali tanggal pekerjaan, angka capaian, status ketersediaan, dan kontak. Angka berasal dari source pengguna; belum diverifikasi secara independen. Pastikan seluruh Google Drive/Sheets/Notion dapat dibuka dengan izin yang sesuai. Tidak ada CV yang dilampirkan karena file CV belum diberikan. Mockup SKD merupakan aset asli dan masih menampilkan label tanggal pada sumbu grafik; sebaiknya diganti dengan screenshot yang sudah dikoreksi jika akan dipublikasikan sebagai bukti analisis data.

## Validasi versi ini

Source diperiksa untuk sintaks JavaScript, keberadaan aset, anchor internal, dan konsistensi key terjemahan. Pengujian visual browser lintas perangkat dan publikasi GitHub belum dilakukan; lakukan pemeriksaan akhir pada desktop dan HP setelah upload. ZIP ini adalah source siap upload, bukan bukti website sudah diterbitkan.
